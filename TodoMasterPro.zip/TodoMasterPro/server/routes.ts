import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { User } from "@shared/schema";

function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Projects API
  app.get("/api/projects", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const projects = await storage.getProjects(user.id);
    res.json(projects);
  });
  
  app.post("/api/projects", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const project = await storage.createProject({
      ...req.body,
      userId: user.id
    });
    res.status(201).json(project);
  });
  
  app.put("/api/projects/:id", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const project = await storage.getProject(parseInt(req.params.id));
    
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    
    if (project.userId !== user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const updatedProject = await storage.updateProject(parseInt(req.params.id), req.body);
    res.json(updatedProject);
  });
  
  app.delete("/api/projects/:id", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const project = await storage.getProject(parseInt(req.params.id));
    
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    
    if (project.userId !== user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    await storage.deleteProject(parseInt(req.params.id));
    res.status(204).end();
  });
  
  // Tasks API
  app.get("/api/tasks", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const tasks = await storage.getTasks(user.id);
    res.json(tasks);
  });
  
  app.post("/api/tasks", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const task = await storage.createTask({
      ...req.body,
      userId: user.id
    });
    res.status(201).json(task);
  });
  
  app.put("/api/tasks/:id", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const task = await storage.getTask(parseInt(req.params.id));
    
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    
    if (task.userId !== user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const updatedTask = await storage.updateTask(parseInt(req.params.id), req.body);
    res.json(updatedTask);
  });
  
  app.delete("/api/tasks/:id", isAuthenticated, async (req, res) => {
    const user = req.user as User;
    const task = await storage.getTask(parseInt(req.params.id));
    
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    
    if (task.userId !== user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    await storage.deleteTask(parseInt(req.params.id));
    res.status(204).end();
  });

  const httpServer = createServer(app);
  return httpServer;
}
