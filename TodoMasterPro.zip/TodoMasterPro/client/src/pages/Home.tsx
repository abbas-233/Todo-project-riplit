import React, { useState } from 'react';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import TaskList from '@/components/TaskList';
import TaskFormModal from '@/components/TaskFormModal';
import ProjectFormModal from '@/components/ProjectFormModal';
import { Task, Project } from '@/lib/types';

const Home: React.FC = () => {
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | undefined>(undefined);
  const [projectToEdit, setProjectToEdit] = useState<Project | undefined>(undefined);
  
  const handleAddTask = () => {
    setTaskToEdit(undefined);
    setTaskModalOpen(true);
  };
  
  const handleEditTask = (task: Task) => {
    setTaskToEdit(task);
    setTaskModalOpen(true);
  };
  
  const handleAddProject = () => {
    setProjectToEdit(undefined);
    setProjectModalOpen(true);
  };
  
  const handleEditProject = (project: Project) => {
    setProjectToEdit(project);
    setProjectModalOpen(true);
  };
  
  return (
    <div className="flex flex-col h-screen">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar onAddProject={handleAddProject} />
        
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <TaskList 
            onAddTask={handleAddTask}
            onEditTask={handleEditTask}
          />
        </main>
      </div>
      
      <TaskFormModal 
        isOpen={taskModalOpen}
        onClose={() => setTaskModalOpen(false)}
        task={taskToEdit}
      />
      
      <ProjectFormModal 
        isOpen={projectModalOpen}
        onClose={() => setProjectModalOpen(false)}
        project={projectToEdit}
      />
    </div>
  );
};

export default Home;
