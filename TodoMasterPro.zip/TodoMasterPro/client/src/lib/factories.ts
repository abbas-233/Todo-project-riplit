import { Task, Project, Priority, ProjectColor } from './types';
import { format } from 'date-fns';

/**
 * Factory function to create a new task
 */
export function createTask({
  title,
  description = '',
  dueDate,
  priority = 'medium',
  projectId = 'default',
  notes = [],
  completed = false,
}: {
  title: string;
  description?: string;
  dueDate: string;
  priority?: Priority;
  projectId?: string;
  notes?: string[];
  completed?: boolean;
}): Omit<Task, 'id'> {
  return {
    title,
    description,
    dueDate,
    priority,
    projectId,
    notes,
    completed,
  };
}

/**
 * Factory function to create a new project
 */
export function createProject({
  name,
  color = 'primary',
}: {
  name: string;
  color?: ProjectColor;
}): Omit<Project, 'id'> {
  return {
    name,
    color,
  };
}

/**
 * Format date for display
 */
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  
  // Check if it's today
  const today = new Date();
  if (format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) {
    return 'Today';
  }
  
  // Check if it's tomorrow
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  if (format(date, 'yyyy-MM-dd') === format(tomorrow, 'yyyy-MM-dd')) {
    return 'Tomorrow';
  }
  
  // Check if it's within a week
  const nextWeek = new Date(today);
  nextWeek.setDate(nextWeek.getDate() + 7);
  if (date <= nextWeek) {
    return 'Next week';
  }
  
  // Otherwise return formatted date
  return format(date, 'MMM d, yyyy');
}

/**
 * Get priority CSS classes
 */
export function getPriorityClasses(priority: Priority): {
  borderClass: string;
  bgClass: string;
  textClass: string;
  borderColorClass: string;
} {
  switch (priority) {
    case 'high':
      return {
        borderClass: 'border-highPriority',
        bgClass: 'bg-red-100',
        textClass: 'text-red-800',
        borderColorClass: 'border-highPriority',
      };
    case 'medium':
      return {
        borderClass: 'border-mediumPriority',
        bgClass: 'bg-yellow-100',
        textClass: 'text-yellow-800',
        borderColorClass: 'border-mediumPriority',
      };
    case 'low':
      return {
        borderClass: 'border-lowPriority',
        bgClass: 'bg-blue-100',
        textClass: 'text-blue-800',
        borderColorClass: 'border-lowPriority',
      };
    default:
      return {
        borderClass: 'border-gray-300',
        bgClass: 'bg-gray-100',
        textClass: 'text-gray-800',
        borderColorClass: 'border-gray-300',
      };
  }
}

/**
 * Get project color CSS classes
 */
export function getProjectColorClass(color: ProjectColor): string {
  switch (color) {
    case 'primary':
      return 'bg-primary';
    case 'lowPriority':
      return 'bg-lowPriority';
    case 'mediumPriority':
      return 'bg-mediumPriority';
    case 'success':
      return 'bg-success';
    default:
      return 'bg-gray-500';
  }
}

/**
 * Generate a unique ID
 */
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}
