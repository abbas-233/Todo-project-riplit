import { Task, Project } from './types';
import { generateId } from './factories';

const TASKS_STORAGE_KEY = 'todolist_tasks';
const PROJECTS_STORAGE_KEY = 'todolist_projects';

/**
 * Initialize default project if no projects exist
 */
function initializeDefaultProject(): Project[] {
  const defaultProjects: Project[] = [
    { id: 'default', name: 'Personal', color: 'primary' },
    { id: 'work', name: 'Work', color: 'lowPriority' },
    { id: 'shopping', name: 'Shopping', color: 'success' }
  ];
  
  localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(defaultProjects));
  return defaultProjects;
}

/**
 * Initialize default tasks if storage is empty
 */
function initializeDefaultTasks(): Task[] {
  return [];
}

/**
 * Load tasks from localStorage
 */
export function loadTasks(): Task[] {
  try {
    const tasksJson = localStorage.getItem(TASKS_STORAGE_KEY);
    if (!tasksJson) {
      return initializeDefaultTasks();
    }
    return JSON.parse(tasksJson);
  } catch (error) {
    console.error('Error loading tasks from localStorage:', error);
    return initializeDefaultTasks();
  }
}

/**
 * Save tasks to localStorage
 */
export function saveTasks(tasks: Task[]): void {
  try {
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    console.error('Error saving tasks to localStorage:', error);
  }
}

/**
 * Load projects from localStorage
 */
export function loadProjects(): Project[] {
  try {
    const projectsJson = localStorage.getItem(PROJECTS_STORAGE_KEY);
    if (!projectsJson) {
      return initializeDefaultProject();
    }
    return JSON.parse(projectsJson);
  } catch (error) {
    console.error('Error loading projects from localStorage:', error);
    return initializeDefaultProject();
  }
}

/**
 * Save projects to localStorage
 */
export function saveProjects(projects: Project[]): void {
  try {
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
  } catch (error) {
    console.error('Error saving projects to localStorage:', error);
  }
}

/**
 * Add a new task
 */
export function addTask(task: Omit<Task, 'id'>): Task {
  const tasks = loadTasks();
  const newTask = { ...task, id: generateId() };
  
  saveTasks([...tasks, newTask]);
  return newTask;
}

/**
 * Edit an existing task
 */
export function editTask(id: string, updatedTask: Partial<Task>): void {
  const tasks = loadTasks();
  const updatedTasks = tasks.map(task => 
    task.id === id ? { ...task, ...updatedTask } : task
  );
  
  saveTasks(updatedTasks);
}

/**
 * Delete a task
 */
export function deleteTask(id: string): void {
  const tasks = loadTasks();
  const updatedTasks = tasks.filter(task => task.id !== id);
  
  saveTasks(updatedTasks);
}

/**
 * Add a new project
 */
export function addProject(project: Omit<Project, 'id'>): Project {
  const projects = loadProjects();
  const newProject = { ...project, id: generateId() };
  
  saveProjects([...projects, newProject]);
  return newProject;
}

/**
 * Edit an existing project
 */
export function editProject(id: string, updatedProject: Partial<Project>): void {
  const projects = loadProjects();
  const updatedProjects = projects.map(project => 
    project.id === id ? { ...project, ...updatedProject } : project
  );
  
  saveProjects(updatedProjects);
}

/**
 * Delete a project
 */
export function deleteProject(id: string): void {
  // Do not delete default project
  if (id === 'default') {
    return;
  }
  
  const projects = loadProjects();
  const updatedProjects = projects.filter(project => project.id !== id);
  
  saveProjects(updatedProjects);
  
  // Update all tasks from the deleted project to be in the default project
  const tasks = loadTasks();
  const updatedTasks = tasks.map(task => 
    task.projectId === id ? { ...task, projectId: 'default' } : task
  );
  
  saveTasks(updatedTasks);
}

/**
 * Toggle task completion status
 */
export function toggleTaskCompletion(id: string): void {
  const tasks = loadTasks();
  const updatedTasks = tasks.map(task => 
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  
  saveTasks(updatedTasks);
}

/**
 * Get all tasks for a specific project
 */
export function getTasksByProject(projectId: string): Task[] {
  const tasks = loadTasks();
  
  if (projectId === 'all') {
    return tasks;
  }
  
  return tasks.filter(task => task.projectId === projectId);
}

/**
 * Get today's tasks
 */
export function getTodayTasks(): Task[] {
  const tasks = loadTasks();
  const today = new Date().toISOString().split('T')[0];
  
  return tasks.filter(task => {
    const taskDate = task.dueDate.split('T')[0];
    return taskDate === today;
  });
}

/**
 * Get upcoming tasks (due within the next 7 days)
 */
export function getUpcomingTasks(): Task[] {
  const tasks = loadTasks();
  const today = new Date();
  const nextWeek = new Date();
  nextWeek.setDate(today.getDate() + 7);
  
  return tasks.filter(task => {
    const dueDate = new Date(task.dueDate);
    return dueDate >= today && dueDate <= nextWeek;
  });
}
