export interface Project {
  id: string;
  name: string;
  color: string;
}

export type ProjectColor = 'primary' | 'lowPriority' | 'mediumPriority' | 'success';

export type ProjectId = string;

export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  priority: Priority;
  completed: boolean;
  projectId: ProjectId;
  notes?: string[];
}

export type Filter = 'all' | 'active' | 'completed';

export interface TodoContextType {
  tasks: Task[];
  projects: Project[];
  activeProject: ProjectId | 'all' | 'today' | 'upcoming';
  filter: Filter;
  setActiveProject: (projectId: ProjectId | 'all' | 'today' | 'upcoming') => void;
  setFilter: (filter: Filter) => void;
  addTask: (task: Omit<Task, 'id'>) => void;
  editTask: (id: string, updatedTask: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskCompletion: (id: string) => void;
  addProject: (project: Omit<Project, 'id'>) => void;
  editProject: (id: string, updatedProject: Partial<Project>) => void;
  deleteProject: (id: string) => void;
}
