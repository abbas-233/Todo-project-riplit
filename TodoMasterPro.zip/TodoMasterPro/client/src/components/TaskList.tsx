import React, { useState } from 'react';
import { useTodo } from '@/contexts/TodoContext';
import TaskItem from './TaskItem';
import { Task, Filter } from '@/lib/types';
import { Plus } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface TaskListProps {
  onAddTask: () => void;
  onEditTask: (task: Task) => void;
}

const TaskList: React.FC<TaskListProps> = ({ onAddTask, onEditTask }) => {
  const { tasks, activeProject, filter, setFilter } = useTodo();

  // Get the title based on the active project
  const getTitle = () => {
    if (activeProject === 'all') return 'All Tasks';
    if (activeProject === 'today') return 'Today';
    if (activeProject === 'upcoming') return 'Upcoming';
    return useTodo().projects.find(project => project.id === activeProject)?.name || 'Tasks';
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 font-inter">{getTitle()}</h2>
        <div className="flex">
          <div className="mr-4">
            <Select value={filter} onValueChange={(value) => setFilter(value as Filter)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <button 
            type="button" 
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-[#c43c2f] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            onClick={onAddTask}
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Task
          </button>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-4">
        {tasks.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500 font-roboto">No tasks found. Add a new task to get started!</p>
          </div>
        ) : (
          tasks.map(task => (
            <TaskItem 
              key={task.id} 
              task={task}
              onEdit={onEditTask}
            />
          ))
        )}
      </div>

      {/* Fixed add button for mobile */}
      <div className="fixed bottom-6 right-6 md:hidden">
        <button 
          type="button" 
          className="inline-flex items-center p-3 border border-transparent rounded-full shadow-lg text-white bg-primary hover:bg-[#c43c2f] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          onClick={onAddTask}
        >
          <Plus className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
};

export default TaskList;
