import React, { useState, useEffect } from 'react';
import { Project, ProjectColor } from '@/lib/types';
import { useTodo } from '@/contexts/TodoContext';
import { createProject } from '@/lib/factories';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

interface ProjectFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  project?: Project;
}

const ProjectFormModal: React.FC<ProjectFormModalProps> = ({ isOpen, onClose, project }) => {
  const { addProject, editProject } = useTodo();
  
  const [name, setName] = useState('');
  const [color, setColor] = useState<ProjectColor>('primary');
  
  // Set default values or populate from project for editing
  useEffect(() => {
    if (project) {
      setName(project.name);
      setColor(project.color as ProjectColor);
    } else {
      // Default values for new project
      setName('');
      setColor('primary');
    }
  }, [project, isOpen]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      alert('Please enter a project name');
      return;
    }
    
    if (project) {
      // Edit existing project
      editProject(project.id, {
        name,
        color
      });
    } else {
      // Create new project
      addProject(createProject({
        name,
        color
      }));
    }
    
    onClose();
  };
  
  const colorOptions: { value: ProjectColor; label: string; bgClass: string }[] = [
    { value: 'primary', label: 'Red', bgClass: 'bg-primary' },
    { value: 'lowPriority', label: 'Blue', bgClass: 'bg-lowPriority' },
    { value: 'success', label: 'Green', bgClass: 'bg-success' },
    { value: 'mediumPriority', label: 'Yellow', bgClass: 'bg-mediumPriority' },
  ];
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-gray-900 font-inter">
            {project ? 'Edit Project' : 'Add New Project'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="project-name" className="text-sm font-medium text-gray-700 font-roboto">Project Name</Label>
            <Input 
              id="project-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Project name"
              className="mt-1"
              required
            />
          </div>
          
          <div>
            <Label className="text-sm font-medium text-gray-700 font-roboto mb-2 block">Color</Label>
            <RadioGroup value={color} onValueChange={(value) => setColor(value as ProjectColor)} className="flex space-x-4">
              {colorOptions.map((option) => (
                <div key={option.value} className="flex items-center">
                  <RadioGroupItem id={`color-${option.value}`} value={option.value} className="hidden" />
                  <Label
                    htmlFor={`color-${option.value}`}
                    className={`h-6 w-6 rounded-full ${option.bgClass} border border-gray-300 cursor-pointer ${color === option.value ? 'ring-2 ring-offset-2 ring-primary' : ''}`}
                  />
                </div>
              ))}
            </RadioGroup>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              className="mt-3 w-full sm:mt-0 sm:w-auto"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="w-full sm:ml-3 sm:w-auto bg-primary hover:bg-[#c43c2f]"
            >
              {project ? 'Update Project' : 'Save Project'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectFormModal;
