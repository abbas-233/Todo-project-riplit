import React from 'react';
import { useTodo } from '@/contexts/TodoContext';
import { Search, Home, Calendar, Clock, Plus } from 'lucide-react';
import { Project } from '@/lib/types';
import { getProjectColorClass } from '@/lib/factories';

interface SidebarProps {
  onAddProject: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onAddProject }) => {
  const { 
    projects, 
    activeProject, 
    setActiveProject,
    tasks
  } = useTodo();

  // Count tasks for each category
  const allTasksCount = tasks.length;
  const todayTasksCount = tasks.filter(task => {
    const today = new Date().toISOString().split('T')[0];
    return task.dueDate.split('T')[0] === today;
  }).length;
  const upcomingTasksCount = tasks.filter(task => {
    const today = new Date();
    const dueDate = new Date(task.dueDate);
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    return dueDate >= today && dueDate <= nextWeek;
  }).length;

  // Count tasks per project
  const getProjectTaskCount = (projectId: string) => {
    return tasks.filter(task => task.projectId === projectId).length;
  };

  return (
    <aside id="sidebar" className="bg-white w-64 shadow-md hidden md:block overflow-y-auto transition-all duration-300 ease-in-out">
      <div className="p-4">
        <div className="flex items-center mb-6">
          <Search className="h-5 w-5 text-gray-500" />
          <input 
            type="text" 
            placeholder="Search tasks..." 
            className="ml-2 w-full border-0 focus:ring-0 text-sm text-gray-600 font-roboto" 
          />
        </div>

        <div className="space-y-1 mb-6">
          <a 
            href="#" 
            className={`flex items-center px-2 py-2 rounded-md hover:bg-gray-100 ${activeProject === 'all' ? 'bg-gray-100' : ''}`}
            onClick={(e) => {
              e.preventDefault();
              setActiveProject('all');
            }}
          >
            <Home className="h-5 w-5 text-primary" />
            <span className="ml-3 text-sm font-medium text-gray-900 font-roboto">All Tasks</span>
            <span className="ml-auto bg-gray-200 text-gray-700 text-xs font-medium px-2 py-0.5 rounded-full">{allTasksCount}</span>
          </a>
          <a 
            href="#" 
            className={`flex items-center px-2 py-2 rounded-md hover:bg-gray-100 ${activeProject === 'today' ? 'bg-gray-100' : ''}`}
            onClick={(e) => {
              e.preventDefault();
              setActiveProject('today');
            }}
          >
            <Calendar className="h-5 w-5 text-gray-500" />
            <span className="ml-3 text-sm font-medium text-gray-700 font-roboto">Today</span>
            <span className="ml-auto bg-gray-200 text-gray-700 text-xs font-medium px-2 py-0.5 rounded-full">{todayTasksCount}</span>
          </a>
          <a 
            href="#" 
            className={`flex items-center px-2 py-2 rounded-md hover:bg-gray-100 ${activeProject === 'upcoming' ? 'bg-gray-100' : ''}`}
            onClick={(e) => {
              e.preventDefault();
              setActiveProject('upcoming');
            }}
          >
            <Clock className="h-5 w-5 text-gray-500" />
            <span className="ml-3 text-sm font-medium text-gray-700 font-roboto">Upcoming</span>
            <span className="ml-auto bg-gray-200 text-gray-700 text-xs font-medium px-2 py-0.5 rounded-full">{upcomingTasksCount}</span>
          </a>
        </div>

        <div className="border-t border-gray-200 py-4">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Projects</h3>
          <div className="mt-3 space-y-1">
            {projects.map((project: Project) => (
              <a 
                key={project.id}
                href="#" 
                className={`flex items-center px-2 py-2 rounded-md hover:bg-gray-100 ${activeProject === project.id ? 'bg-gray-100' : ''}`}
                onClick={(e) => {
                  e.preventDefault();
                  setActiveProject(project.id);
                }}
              >
                <span className={`w-2 h-2 rounded-full ${getProjectColorClass(project.color as any)}`}></span>
                <span className="ml-3 text-sm font-medium text-gray-700 font-roboto">{project.name}</span>
                <span className="ml-auto bg-gray-200 text-gray-700 text-xs font-medium px-2 py-0.5 rounded-full">
                  {getProjectTaskCount(project.id)}
                </span>
              </a>
            ))}
          </div>
          <button 
            className="mt-3 flex items-center px-2 py-2 w-full text-left rounded-md hover:bg-gray-100 text-primary"
            onClick={onAddProject}
          >
            <Plus className="h-5 w-5" />
            <span className="ml-3 text-sm font-medium font-roboto">Add Project</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
