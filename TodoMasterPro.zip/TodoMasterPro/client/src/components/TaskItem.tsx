import React, { useState } from 'react';
import { Task } from '@/lib/types';
import { useTodo } from '@/contexts/TodoContext';
import { MoreVertical, Calendar, MessageSquare, Check } from 'lucide-react';
import { formatDate, getPriorityClasses } from '@/lib/factories';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface TaskItemProps {
  task: Task;
  onEdit: (task: Task) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onEdit }) => {
  const { toggleTaskCompletion, deleteTask } = useTodo();
  const [isOpen, setIsOpen] = useState(false);
  
  const { borderClass, bgClass, textClass } = getPriorityClasses(task.priority);
  
  return (
    <div className={`bg-white rounded-lg shadow-sm ${task.completed ? 'opacity-70' : `border-l-4 ${borderClass}`}`}>
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <button
              className={`h-5 w-5 rounded-full ${task.completed 
                ? 'bg-success border-2 border-success text-white' 
                : `border-2 ${borderClass} hover:bg-gray-100`} 
                focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary`}
              onClick={() => toggleTaskCompletion(task.id)}
            >
              {task.completed && (
                <Check className="h-3 w-3 mx-auto" />
              )}
            </button>
          </div>
          <div className="ml-3 flex-1">
            <div className="flex justify-between">
              <p className={`text-sm font-medium ${task.completed ? 'text-gray-500 line-through' : 'text-gray-900'} font-roboto`}>
                {task.title}
              </p>
              <div className="flex space-x-2">
                {!task.completed && (
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${bgClass} ${textClass}`}>
                    {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                  </span>
                )}
                <Popover open={isOpen} onOpenChange={setIsOpen}>
                  <PopoverTrigger asChild>
                    <button className="text-gray-400 hover:text-gray-500">
                      <MoreVertical className="h-5 w-5" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-48 p-0">
                    <div className="py-1">
                      <button
                        className="text-gray-700 block w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
                        onClick={() => {
                          setIsOpen(false);
                          onEdit(task);
                        }}
                      >
                        Edit
                      </button>
                      <button
                        className="text-red-600 block w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
                        onClick={() => {
                          setIsOpen(false);
                          deleteTask(task.id);
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            {task.description && (
              <p className={`mt-1 text-sm ${task.completed ? 'text-gray-400 line-through' : 'text-gray-500'} font-roboto`}>
                {task.description}
              </p>
            )}
            <div className={`mt-2 flex items-center text-xs ${task.completed ? 'text-gray-400' : 'text-gray-500'} font-roboto`}>
              <Calendar className="h-4 w-4 mr-1 text-gray-400" />
              {formatDate(task.dueDate)}
              
              {task.notes && task.notes.length > 0 && (
                <>
                  <span className="mx-2">•</span>
                  <MessageSquare className="h-4 w-4 mr-1 text-gray-400" />
                  {task.notes.length} notes
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskItem;
