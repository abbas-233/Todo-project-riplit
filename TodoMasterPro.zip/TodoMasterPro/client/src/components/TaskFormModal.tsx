import React, { useState, useEffect } from 'react';
import { Task, Project } from '@/lib/types';
import { useTodo } from '@/contexts/TodoContext';
import { createTask } from '@/lib/factories';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface TaskFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  task?: Task;
}

const TaskFormModal: React.FC<TaskFormModalProps> = ({ isOpen, onClose, task }) => {
  const { addTask, editTask, projects, activeProject } = useTodo();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('medium');
  const [projectId, setProjectId] = useState('');
  
  // Set default values or populate from task for editing
  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description || '');
      setDueDate(task.dueDate);
      setPriority(task.priority);
      setProjectId(task.projectId);
    } else {
      // Default values for new task
      setTitle('');
      setDescription('');
      setDueDate(new Date().toISOString().split('T')[0]);
      setPriority('medium');
      // Set active project as default, or 'default' if activeProject is a filter
      setProjectId(['all', 'today', 'upcoming'].includes(activeProject) ? 'default' : activeProject);
    }
  }, [task, activeProject, isOpen]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      alert('Please enter a title');
      return;
    }
    
    if (task) {
      // Edit existing task
      editTask(task.id, {
        title,
        description,
        dueDate,
        priority: priority as any,
        projectId
      });
    } else {
      // Create new task
      addTask(createTask({
        title,
        description,
        dueDate,
        priority: priority as any,
        projectId
      }));
    }
    
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-gray-900 font-inter">
            {task ? 'Edit Task' : 'Add New Task'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="task-title" className="text-sm font-medium text-gray-700 font-roboto">Title</Label>
            <Input 
              id="task-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Task title"
              className="mt-1"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="task-description" className="text-sm font-medium text-gray-700 font-roboto">Description</Label>
            <Textarea 
              id="task-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Task description"
              className="mt-1"
              rows={3}
            />
          </div>
          
          <div className="flex space-x-4">
            <div className="w-1/2">
              <Label htmlFor="task-due-date" className="text-sm font-medium text-gray-700 font-roboto">Due Date</Label>
              <Input 
                id="task-due-date"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="mt-1"
                required
              />
            </div>
            
            <div className="w-1/2">
              <Label htmlFor="task-priority" className="text-sm font-medium text-gray-700 font-roboto">Priority</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger id="task-priority" className="mt-1">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="task-project" className="text-sm font-medium text-gray-700 font-roboto">Project</Label>
            <Select value={projectId} onValueChange={setProjectId}>
              <SelectTrigger id="task-project" className="mt-1">
                <SelectValue placeholder="Select project" />
              </SelectTrigger>
              <SelectContent>
                {projects.map((project: Project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              className="mt-3 w-full sm:mt-0 sm:w-auto"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="w-full sm:ml-3 sm:w-auto bg-primary hover:bg-[#c43c2f]"
            >
              {task ? 'Update' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TaskFormModal;
