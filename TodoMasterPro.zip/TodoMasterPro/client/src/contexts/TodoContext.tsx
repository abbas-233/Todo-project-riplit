import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Task, Project, TodoContextType, Filter } from '@/lib/types';
import * as todoStorage from '@/lib/todoStorage';

// Create the context with a default value
const TodoContext = createContext<TodoContextType | undefined>(undefined);

// Create a provider component
export function TodoProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<string>('all');
  const [filter, setFilter] = useState<Filter>('all');

  // Load initial data from localStorage
  useEffect(() => {
    const loadedTasks = todoStorage.loadTasks();
    const loadedProjects = todoStorage.loadProjects();
    
    setTasks(loadedTasks);
    setProjects(loadedProjects);
  }, []);

  // Add a new task
  const addTask = (task: Omit<Task, 'id'>) => {
    const newTask = todoStorage.addTask(task);
    setTasks([...tasks, newTask]);
  };

  // Edit an existing task
  const editTask = (id: string, updatedTask: Partial<Task>) => {
    todoStorage.editTask(id, updatedTask);
    setTasks(tasks.map(task => task.id === id ? { ...task, ...updatedTask } : task));
  };

  // Delete a task
  const deleteTask = (id: string) => {
    todoStorage.deleteTask(id);
    setTasks(tasks.filter(task => task.id !== id));
  };

  // Toggle task completion
  const toggleTaskCompletion = (id: string) => {
    todoStorage.toggleTaskCompletion(id);
    setTasks(tasks.map(task => {
      if (task.id === id) {
        return { ...task, completed: !task.completed };
      }
      return task;
    }));
  };

  // Add a new project
  const addProject = (project: Omit<Project, 'id'>) => {
    const newProject = todoStorage.addProject(project);
    setProjects([...projects, newProject]);
  };

  // Edit an existing project
  const editProject = (id: string, updatedProject: Partial<Project>) => {
    todoStorage.editProject(id, updatedProject);
    setProjects(projects.map(project => project.id === id ? { ...project, ...updatedProject } : project));
  };

  // Delete a project
  const deleteProject = (id: string) => {
    todoStorage.deleteProject(id);
    setProjects(projects.filter(project => project.id !== id));
    
    // Reassign tasks from the deleted project to the default project
    setTasks(tasks.map(task => task.projectId === id ? { ...task, projectId: 'default' } : task));
    
    // If the deleted project was active, switch to 'all'
    if (activeProject === id) {
      setActiveProject('all');
    }
  };

  // Get filtered tasks based on activeProject and filter
  const getFilteredTasks = () => {
    let filteredTasks: Task[] = [];
    
    // First filter by project
    if (activeProject === 'all') {
      filteredTasks = [...tasks];
    } else if (activeProject === 'today') {
      filteredTasks = todoStorage.getTodayTasks();
    } else if (activeProject === 'upcoming') {
      filteredTasks = todoStorage.getUpcomingTasks();
    } else {
      filteredTasks = tasks.filter(task => task.projectId === activeProject);
    }
    
    // Then filter by completion status
    if (filter === 'active') {
      return filteredTasks.filter(task => !task.completed);
    } else if (filter === 'completed') {
      return filteredTasks.filter(task => task.completed);
    }
    
    return filteredTasks;
  };

  // Context value
  const value: TodoContextType = {
    tasks: getFilteredTasks(),
    projects,
    activeProject,
    filter,
    setActiveProject,
    setFilter,
    addTask,
    editTask,
    deleteTask,
    toggleTaskCompletion,
    addProject,
    editProject,
    deleteProject,
  };

  return <TodoContext.Provider value={value}>{children}</TodoContext.Provider>;
}

// Custom hook to use the todo context
export function useTodo() {
  const context = useContext(TodoContext);
  if (context === undefined) {
    throw new Error('useTodo must be used within a TodoProvider');
  }
  return context;
}
